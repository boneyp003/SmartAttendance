package app.com.smartattendancesystem.Core;

public class Constant {

    public static final String PREF_UNIQUE_ID = "unique_id";
    public static final String PREF_STUDENT_NAME = "student_name";
}
